import { supabase } from "../lib/supabase";


// ==========================================
// CONSTANTS
// ==========================================

const SOLD_STATUS = "🔴 Đã bán";
const ACTIVE_STATUS = "🟢 Đang bán";

const SOLD_RETENTION_DAYS = 30;

const SOLD_RETENTION_MS =
  SOLD_RETENTION_DAYS *
  24 *
  60 *
  60 *
  1000;


// ==========================================
// CONVERT SUPABASE CAR → APP CAR
// ==========================================

function mapSupabaseCar(car) {
  if (!car) {
    return null;
  }

  return {
    id: car.id,

    brand: car.brand || "",
    model: car.model || "",
    version: car.version || "",

    year: car.year ?? null,
    color: car.color || "",
    odo: car.odo ?? 0,
    price: car.price ?? 0,

    warranty: car.warranty || "",
    legal: car.legal || "",

    status:
      car.status ||
      ACTIVE_STATUS,

    soldAt:
      car.sold_at ||
      null,

    notes:
      car.notes ||
      "",

    images:
      [],

    aiContent:
      car.metadata?.aiContent || {},

    campaignIds:
      car.metadata?.campaignIds || [],

    queueJobIds:
      car.metadata?.queueJobIds || [],

    workPlanIds:
      car.metadata?.workPlanIds || [],

    createdAt:
      car.created_at ||
      null,

    updatedAt:
      car.updated_at ||
      null,

    metadata:
      car.metadata ||
      {},
  };
}


// ==========================================
// CONVERT APP CAR → SUPABASE
// ==========================================

function mapCarToSupabase(car) {
  return {
    brand: car.brand || "",
    model: car.model || "",
    version: car.version || "",

    year: car.year ?? null,
    color: car.color || "",

    odo:
      Number(car.odo) || 0,

    price:
      Number(car.price) || 0,

    warranty:
      car.warranty || "",

    legal:
      car.legal || "",

    status:
      car.status ||
      ACTIVE_STATUS,

    sold_at:
      car.soldAt ||
      null,

    notes:
      car.notes ||
      "",

    metadata: {
      ...(car.metadata || {}),

      aiContent:
        car.aiContent ||
        {},

      campaignIds:
        car.campaignIds ||
        [],

      queueJobIds:
        car.queueJobIds ||
        [],

      workPlanIds:
        car.workPlanIds ||
        [],
    },
  };
}


// ==========================================
// GET ALL CARS
// ==========================================

export async function getCarsFromSupabase() {
  const {
    data,
    error,
  } = await supabase
    .from("cars")
    .select("*")
    .order(
      "created_at",
      {
        ascending: false,
      }
    );

  if (error) {
    throw error;
  }

  return (
    data || []
  ).map(
    mapSupabaseCar
  );
}


// ==========================================
// GET CAR BY ID
// ==========================================

export async function getCarByIdFromSupabase(
  id
) {
  const {
    data,
    error,
  } = await supabase
    .from("cars")
    .select("*")
    .eq("id", id)
    .maybeSingle();

  if (error) {
    throw error;
  }

  return mapSupabaseCar(
    data
  );
}


// ==========================================
// CREATE CAR
// ==========================================
//
// Supabase tự tạo UUID.
// Không truyền id từ LocalStorage.
// ==========================================

export async function createCarInSupabase(
  car
) {
  const payload =
    mapCarToSupabase(
      car
    );

  const {
    data,
    error,
  } = await supabase
    .from("cars")
    .insert(
      payload
    )
    .select()
    .single();

  if (error) {
    throw error;
  }

  return mapSupabaseCar(
    data
  );
}


// ==========================================
// UPDATE CAR
// ==========================================

export async function updateCarInSupabase(
  id,
  updatedData
) {

  // Đọc bản hiện tại trước để không
  // làm mất metadata khác.

  const {
    data: existingCar,
    error: readError,
  } = await supabase
    .from("cars")
    .select("*")
    .eq("id", id)
    .maybeSingle();

  if (readError) {
    throw readError;
  }

  if (!existingCar) {
    throw new Error(
      "Không tìm thấy xe trên Supabase."
    );
  }


  const currentCar =
    mapSupabaseCar(
      existingCar
    );


  const mergedCar = {
    ...currentCar,
    ...updatedData,

    aiContent: {
      ...(currentCar.aiContent || {}),
      ...(updatedData.aiContent || {}),
    },

    campaignIds:
      updatedData.campaignIds ??
      currentCar.campaignIds ??
      [],

    queueJobIds:
      updatedData.queueJobIds ??
      currentCar.queueJobIds ??
      [],

    workPlanIds:
      updatedData.workPlanIds ??
      currentCar.workPlanIds ??
      [],
  };


  const payload =
    mapCarToSupabase(
      mergedCar
    );


  const {
    data,
    error,
  } = await supabase
    .from("cars")
    .update(
      payload
    )
    .eq("id", id)
    .select()
    .single();

  if (error) {
    throw error;
  }

  return mapSupabaseCar(
    data
  );
}


// ==========================================
// MARK CAR AS SOLD
// ==========================================

export async function markCarAsSoldInSupabase(
  id
) {

  const soldAt =
    new Date().toISOString();


  const {
    data,
    error,
  } = await supabase
    .from("cars")
    .update({
      status:
        SOLD_STATUS,

      sold_at:
        soldAt,
    })
    .eq("id", id)
    .select()
    .single();

  if (error) {
    throw error;
  }

  return mapSupabaseCar(
    data
  );
}


// ==========================================
// GET SOLD CARS
// ==========================================

export async function getSoldCarsFromSupabase() {

  const {
    data,
    error,
  } = await supabase
    .from("cars")
    .select("*")
    .eq(
      "status",
      SOLD_STATUS
    )
    .order(
      "sold_at",
      {
        ascending: false,
      }
    );

  if (error) {
    throw error;
  }

  return (
    data || []
  ).map(
    mapSupabaseCar
  );
}


// ==========================================
// GET ACTIVE CARS
// ==========================================

export async function getActiveCarsFromSupabase() {

  const {
    data,
    error,
  } = await supabase
    .from("cars")
    .select("*")
    .neq(
      "status",
      SOLD_STATUS
    )
    .order(
      "created_at",
      {
        ascending: false,
      }
    );

  if (error) {
    throw error;
  }

  return (
    data || []
  ).map(
    mapSupabaseCar
  );
}


// ==========================================
// RESTORE SOLD CAR AS NEW CAR
// ==========================================
//
// Tạo record mới.
// Không giữ ID cũ.
// Không mang campaign / queue / workPlan.
// ==========================================

export async function restoreSoldCarInSupabase(
  id
) {

  const oldCar =
    await getCarByIdFromSupabase(
      id
    );


  if (!oldCar) {
    throw new Error(
      "Không tìm thấy xe."
    );
  }


  if (
    oldCar.status !==
    SOLD_STATUS
  ) {
    throw new Error(
      "Xe này không nằm trong mục Đã bán."
    );
  }


  const newCar = {
    ...oldCar,

    id:
      undefined,

    status:
      ACTIVE_STATUS,

    soldAt:
      null,

    campaignIds:
      [],

    queueJobIds:
      [],

    workPlanIds:
      [],

    images:
      [],
  };


  delete newCar.id;


  return createCarInSupabase(
    newCar
  );
}


// ==========================================
// DELETE CAR
// ==========================================

export async function deleteCarFromSupabase(
  id
) {

  const {
    error,
  } = await supabase
    .from("cars")
    .delete()
    .eq(
      "id",
      id
    );

  if (error) {
    throw error;
  }

  return true;
}


// ==========================================
// SOLD DAYS REMAINING
// ==========================================

export function getSoldDaysRemainingFromSupabase(
  car
) {

  if (
    !car ||
    car.status !==
      SOLD_STATUS ||
    !car.soldAt
  ) {
    return null;
  }


  const soldTime =
    new Date(
      car.soldAt
    ).getTime();


  if (
    Number.isNaN(
      soldTime
    )
  ) {
    return null;
  }


  const remaining =
    SOLD_RETENTION_MS -
    (
      Date.now() -
      soldTime
    );


  if (
    remaining <= 0
  ) {
    return 0;
  }


  return Math.ceil(
    remaining /
      (
        24 *
        60 *
        60 *
        1000
      )
  );
}


// ==========================================
// EXPORT CONSTANTS
// ==========================================

export {
  SOLD_STATUS,
  ACTIVE_STATUS,
  SOLD_RETENTION_DAYS,
};