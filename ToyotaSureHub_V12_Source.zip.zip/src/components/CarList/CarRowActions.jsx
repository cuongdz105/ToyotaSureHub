import Button from "../UI/Button";

function CarRowActions({
  car,
  navigate,
  onDelete,
  onMarkAsSold,
}) {

  const handleFacebook = () => {
    console.log(
      "Facebook Campaign",
      car
    );
  };

  const handleTikTok = () => {
    console.log(
      "TikTok Campaign",
      car
    );
  };

  const handleAI = () => {
    console.log(
      "AI",
      car
    );
  };

  const handleMarkAsSold = () => {
    if (
      typeof onMarkAsSold ===
      "function"
    ) {
      onMarkAsSold(car);
    }
  };

  return (
    <>
      <Button
        variant="secondary"
        onClick={() =>
          navigate(
            `/cars/${car.id}`
          )
        }
      >
        👁️
      </Button>

      <Button
        onClick={() =>
          navigate(
            `/edit/${car.id}`
          )
        }
      >
        ✏️
      </Button>

      <Button
        onClick={handleAI}
      >
        🤖
      </Button>

      <Button
        onClick={handleFacebook}
      >
        📣
      </Button>

      <Button
        onClick={handleTikTok}
      >
        🎬
      </Button>

      {/* =====================================
          ĐÁNH DẤU XE ĐÃ BÁN
      ===================================== */}

      {car.status !==
        "🔴 Đã bán" && (
        <Button
          onClick={
            handleMarkAsSold
          }
        >
          🔴 Đã bán
        </Button>
      )}

      <Button
        variant="danger"
        onClick={() =>
          onDelete(car.id)
        }
      >
        🗑️
      </Button>
    </>
  );
}

export default CarRowActions;